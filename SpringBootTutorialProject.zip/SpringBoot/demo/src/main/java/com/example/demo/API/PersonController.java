package com.example.demo.API;

import com.example.demo.Model.Person;
import com.example.demo.Service.PersonVervice;

public class PersonController {
    private final PersonVervice personVervice;

    public PersonController(PersonVervice personVervice) {
        this.personVervice = personVervice;
    }

    public void addPerson(Person person) {
        personVervice.addPerson(person);
    }
}
