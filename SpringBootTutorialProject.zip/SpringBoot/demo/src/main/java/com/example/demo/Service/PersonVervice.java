package com.example.demo.Service;

import com.example.demo.Dao.PersonDao;
import com.example.demo.Model.Person;

public class PersonVervice {

    private final PersonDao personDao;

    public PersonVervice(PersonDao personDao) {
        this.personDao = personDao;
    }

    public int addPerson(Person person) {
        return personDao.insertPerson(person);
    }
}
